// 
// Decompiled by Procyon v0.5.36
// 

package me.mindlessly.notenoughcoins.commands.subcommands;

import me.mindlessly.notenoughcoins.Main;
import net.minecraft.command.ICommandSender;
import me.mindlessly.notenoughcoins.utils.Utils;
import me.mindlessly.notenoughcoins.Config;

public class Toggle implements Subcommand
{
    public static void updateConfig() {
        if (Config.enabled) {
            Utils.sendMessageWithPrefix("&aFlipper enabled.");
        }
        else {
            Utils.sendMessageWithPrefix("&cFlipper disabled.");
        }
    }
    
    @Override
    public String getCommandName() {
        return "toggle";
    }
    
    @Override
    public boolean isHidden() {
        return false;
    }
    
    @Override
    public String getCommandUsage() {
        return "";
    }
    
    @Override
    public String getCommandDescription() {
        return "Toggles the flipper on or off";
    }
    
    @Override
    public boolean processCommand(final ICommandSender sender, final String[] args) {
        Config.enabled = !Config.enabled;
        Main.config.writeData();
        updateConfig();
        return true;
    }
}
