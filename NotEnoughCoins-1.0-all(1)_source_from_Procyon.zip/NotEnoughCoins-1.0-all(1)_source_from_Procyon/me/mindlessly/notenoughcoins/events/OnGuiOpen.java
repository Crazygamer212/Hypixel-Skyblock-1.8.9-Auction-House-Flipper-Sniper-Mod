// 
// Decompiled by Procyon v0.5.36
// 

package me.mindlessly.notenoughcoins.events;

import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.gui.GuiScreen;
import me.mindlessly.notenoughcoins.utils.updater.UpdateAvailableScreen;
import gg.essential.api.EssentialAPI;
import me.mindlessly.notenoughcoins.utils.updater.GitHub;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraftforge.client.event.GuiOpenEvent;

public class OnGuiOpen
{
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onGuiOpen(final GuiOpenEvent event) {
        if (event.gui == null || event.gui.getClass() != GuiMainMenu.class) {
            return;
        }
        if (!GitHub.shownGUI) {
            GitHub.fetchLatestRelease();
            if (!GitHub.isLatest()) {
                EssentialAPI.getGuiUtil().openScreen((GuiScreen)new UpdateAvailableScreen());
            }
            GitHub.shownGUI = true;
        }
    }
}
