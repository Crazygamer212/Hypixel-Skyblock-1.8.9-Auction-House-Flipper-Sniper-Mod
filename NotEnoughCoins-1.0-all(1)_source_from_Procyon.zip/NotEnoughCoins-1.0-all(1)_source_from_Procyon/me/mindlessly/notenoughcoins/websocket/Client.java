// 
// Decompiled by Procyon v0.5.36
// 

package me.mindlessly.notenoughcoins.websocket;

import java.util.Iterator;
import com.google.gson.JsonObject;
import net.minecraft.util.ResourceLocation;
import gg.essential.universal.USound;
import net.minecraft.event.ClickEvent;
import me.mindlessly.notenoughcoins.Authenticator;
import me.mindlessly.notenoughcoins.objects.AverageItem;
import java.util.Arrays;
import java.util.Locale;
import com.google.gson.JsonElement;
import me.mindlessly.notenoughcoins.utils.Utils;
import me.mindlessly.notenoughcoins.Config;
import com.google.gson.JsonParser;
import me.mindlessly.notenoughcoins.Reference;
import org.java_websocket.handshake.ServerHandshake;
import java.net.URISyntaxException;
import me.mindlessly.notenoughcoins.Main;
import java.util.HashMap;
import java.util.TimerTask;
import java.util.Timer;
import java.util.Map;
import java.net.URI;
import java.util.Date;
import org.java_websocket.client.WebSocketClient;

public class Client extends WebSocketClient
{
    private Date lastPing;
    public long latency;
    
    public Client(final URI serverUri, final Map<String, String> httpHeaders) {
        super(serverUri, httpHeaders);
        this.latency = -1L;
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                Client.this.lastPing = new Date();
                Client.this.send("{\"type\":\"ping\"}");
            }
        }, 1000L, 30000L);
    }
    
    public static void connectWithToken() {
        final Map<String, String> headers = new HashMap<String, String>();
        headers.put("Authorization", Main.authenticator.getToken());
        try {
            new Client(new URI("wss://nec.robothanzo.dev/ws"), headers).connect();
        }
        catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void onOpen(final ServerHandshake handshakedata) {
        Reference.logger.info("Websocket connection established");
    }
    
    @Override
    public void onMessage(final String message) {
        final Date start = new Date();
        final JsonObject json = new JsonParser().parse(message).getAsJsonObject();
        if (json.has("type")) {
            final String asString = json.get("type").getAsString();
            switch (asString) {
                case "profit": {
                    if (Config.enabled && (!Config.onlySkyblock || Utils.isOnSkyblock())) {
                        for (final JsonElement element : json.getAsJsonArray("result")) {
                            final JsonObject item = element.getAsJsonObject();
                            final String auctionID = item.get("auction_id").getAsString();
                            final String itemID = item.get("id").getAsString();
                            if (!Main.processedItem.containsKey(auctionID)) {
                                Main.processedItem.put(auctionID, new Date(item.get("end").getAsLong()));
                                if (Config.categoryFilter.contains(item.get("category").getAsString().toUpperCase(Locale.ROOT)) || Arrays.asList(Config.blacklistedIDs.split("\n")).contains(item.get("id").getAsString())) {
                                    continue;
                                }
                                final int price = item.get("price").getAsInt();
                                final int profit = Utils.getTaxedProfit(price, item.get("profit").getAsInt());
                                int demand;
                                try {
                                    demand = Main.averageItemMap.get(itemID).demand;
                                }
                                catch (NullPointerException e) {
                                    Main.processedItem.remove(auctionID);
                                    continue;
                                }
                                final double profitPercentage = profit / (double)price;
                                if (price > Main.balance || profit < Config.minProfit || profitPercentage < Config.minProfitPercentage || demand < Config.minDemand) {
                                    continue;
                                }
                                if (!Config.manipulationCheck || (price + item.get("profit").getAsInt()) * 0.6 <= Main.averageItemMap.get(itemID).ahAvgPrice) {
                                    if (Authenticator.myUUID.toLowerCase(Locale.ROOT).replaceAll("-", "").equals(item.get("auctioneer").getAsString())) {
                                        continue;
                                    }
                                    Utils.sendMessageWithPrefix(Utils.getColorCodeFromRarity(item.get("rarity").getAsString()) + item.get("item_name").getAsString() + "&e " + Utils.getProfitText(profit) + " &eP: &a" + Utils.formatValue(price) + " &ePP: &a" + (int)Math.floor(profitPercentage * 100.0) + "% &eSPD: &a" + demand + " " + (Config.debug ? ("\n&eCL: &a" + item.get("cache_latency").getAsInt() + "ms") : "") + " " + (Config.debug ? ("&eAL: &a" + item.get("api_latency").getAsInt() + "ms") : "") + " " + (Config.debug ? ("&eWL: &a" + this.latency + "ms") : "") + " " + (Config.debug ? ("&ePL: &a" + (new Date().getTime() - start.getTime()) + "ms") : "") + " " + (Config.debug ? ("&eAA: &a" + Utils.formatValue(Main.averageItemMap.get(itemID).ahAvgPrice)) : "") + " " + (Config.debug ? ("&eLBIN: &a" + Utils.formatValue(Main.lbinItem.get(itemID))) : "") + " " + ((profit >= 100000) ? "\n" : ""), new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/viewauction " + auctionID));
                                    if (!Config.alertSounds || Main.justPlayedASound) {
                                        continue;
                                    }
                                    Main.justPlayedASound = true;
                                    USound.INSTANCE.playSoundStatic(new ResourceLocation("note.pling"), 2.0f, 1.0f);
                                }
                                else {
                                    Reference.logger.info("Failed manipulation check for " + item.get("item_name").getAsString() + " price " + price + " profit " + profit + " avg " + Main.averageItemMap.get(item.get("id").getAsString()).ahAvgPrice);
                                }
                            }
                        }
                    }
                    Main.justPlayedASound = false;
                }
                case "lowest_bin": {
                    for (final Map.Entry<String, JsonElement> entry : json.getAsJsonObject("result").entrySet()) {
                        Main.lbinItem.put(entry.getKey(), entry.getValue().getAsInt());
                    }
                }
                case "average": {
                    for (final Map.Entry<String, JsonElement> entry : json.getAsJsonObject("result").entrySet()) {
                        final String item2 = entry.getKey();
                        final JsonObject itemDetails = entry.getValue().getAsJsonObject();
                        final int sampledDays = itemDetails.getAsJsonPrimitive("sampled_days").getAsInt();
                        final int ahSales = Math.floorDiv(itemDetails.getAsJsonObject("auction").getAsJsonPrimitive("sales").getAsInt(), sampledDays);
                        final int ahAvgPrice = (int)Math.floor(itemDetails.getAsJsonObject("auction").getAsJsonPrimitive("average_price").getAsDouble());
                        final int binSales = Math.floorDiv(itemDetails.getAsJsonObject("bin").getAsJsonPrimitive("sales").getAsInt(), sampledDays);
                        Main.averageItemMap.put(item2, new AverageItem(item2, ahSales + binSales, ahAvgPrice));
                    }
                }
                case "pong": {
                    if (this.lastPing != null) {
                        this.latency = (new Date().getTime() - this.lastPing.getTime()) / 2L;
                        break;
                    }
                    break;
                }
            }
        }
    }
    
    @Override
    public void onClose(final int code, final String reason, final boolean remote) {
        Reference.logger.warn("Websocket connection closed by " + (remote ? "remote peer" : "us") + " Code: " + code + " Reason: " + reason);
        if (reason.contains("418")) {
            Utils.sendMessageWithPrefix("&cFailed to fetch from NEC backend, this might be caused by:\n&cYou have been blacklisted from the mod for using macro scripts\n&cPlease join our discord server for more information (in /nec > links)");
        }
        if (reason.contains("401")) {
            Reference.logger.warn("Token expired, fetching new token");
            try {
                Main.authenticator.authenticate(false);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (code != 1001) {
            connectWithToken();
            try {
                Thread.sleep(1500L);
            }
            catch (InterruptedException e2) {
                e2.printStackTrace();
            }
            Reference.logger.warn("Restarting connection due to abnormal close");
        }
    }
    
    @Override
    public void onError(final Exception ex) {
        Reference.logger.error("Websocket error", (Throwable)ex);
    }
}
