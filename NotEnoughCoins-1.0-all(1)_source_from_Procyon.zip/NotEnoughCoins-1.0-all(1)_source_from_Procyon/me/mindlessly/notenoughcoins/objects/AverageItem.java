// 
// Decompiled by Procyon v0.5.36
// 

package me.mindlessly.notenoughcoins.objects;

public class AverageItem
{
    public String id;
    public int demand;
    public int ahAvgPrice;
    
    public AverageItem(final String id, final int demand, final int ahAvgPrice) {
        this.id = id;
        this.demand = demand;
        this.ahAvgPrice = ahAvgPrice;
    }
}
