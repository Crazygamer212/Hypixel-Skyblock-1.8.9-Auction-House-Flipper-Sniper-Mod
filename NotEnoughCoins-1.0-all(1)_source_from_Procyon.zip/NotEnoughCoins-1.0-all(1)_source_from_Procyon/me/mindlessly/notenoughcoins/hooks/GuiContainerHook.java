// 
// Decompiled by Procyon v0.5.36
// 

package me.mindlessly.notenoughcoins.hooks;

import java.awt.Color;
import net.minecraft.client.gui.Gui;
import me.mindlessly.notenoughcoins.objects.BestSellingMethod;
import me.mindlessly.notenoughcoins.Config;
import net.minecraft.inventory.IInventory;
import java.util.Iterator;
import java.util.List;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.Minecraft;
import me.mindlessly.notenoughcoins.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.Slot;
import net.minecraft.inventory.Container;

public class GuiContainerHook
{
    public static final int GREEN_OVERLAY;
    
    public static boolean isSellMerchant(final Container inventory) {
        if (inventory.field_75151_b.size() <= 49) {
            return false;
        }
        final ItemStack itemStack = inventory.field_75151_b.get(49).func_75211_c();
        if (itemStack != null) {
            if (itemStack.func_77973_b() == Item.func_150898_a((Block)Blocks.field_150438_bZ) && itemStack.func_82837_s() && Utils.removeColorCodes(itemStack.func_82833_r()).equals("Sell Item")) {
                return true;
            }
            final List<String> tooltip = (List<String>)itemStack.func_82840_a((EntityPlayer)Minecraft.func_71410_x().field_71439_g, false);
            for (final String line : tooltip) {
                if (Utils.removeColorCodes(line).equals("Click to buyback!")) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public static boolean isBazaar(final Container inventory) {
        if (inventory.func_75139_a(0) == null) {
            return false;
        }
        final IInventory realInventory = inventory.func_75139_a(0).field_75224_c;
        return realInventory.func_145818_k_() && realInventory.func_145748_c_().func_150260_c().startsWith("Bazaar");
    }
    
    public static boolean isAuction(final Container inventory) {
        if (inventory.func_75139_a(0) == null) {
            return false;
        }
        final IInventory realInventory = inventory.func_75139_a(0).field_75224_c;
        return realInventory.func_145818_k_() && realInventory.func_145748_c_().func_150260_c().contains("Auction");
    }
    
    public static void drawSlot(final Container inventorySlots, final Slot slot) {
        if (Utils.isOnSkyblock() && Config.bestSellingOverlay && slot.func_75216_d()) {
            final BestSellingMethod bestSellingMethod = Utils.getBestSellingMethod(Utils.getIDFromItemStack(slot.func_75211_c())).getKey();
            boolean drawOverlay = bestSellingMethod == BestSellingMethod.NPC && isSellMerchant(inventorySlots);
            if (bestSellingMethod == BestSellingMethod.BAZAAR && isBazaar(inventorySlots)) {
                drawOverlay = true;
            }
            if (bestSellingMethod == BestSellingMethod.LBIN && isAuction(inventorySlots)) {
                drawOverlay = true;
            }
            if (drawOverlay) {
                final int slotLeft = slot.field_75223_e;
                final int slotTop = slot.field_75221_f;
                final int slotRight = slotLeft + 16;
                final int slotBottom = slotTop + 16;
                Gui.func_73734_a(slotLeft, slotTop, slotRight, slotBottom, GuiContainerHook.GREEN_OVERLAY);
            }
        }
    }
    
    static {
        GREEN_OVERLAY = new Color(0, 255, 0, 100).getRGB();
    }
}
