// 
// Decompiled by Procyon v0.5.36
// 

package me.mindlessly.notenoughcoins.mixins;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.mindlessly.notenoughcoins.hooks.GuiContainerHook;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.inventory.Slot;
import org.spongepowered.asm.mixin.Shadow;
import net.minecraft.inventory.Container;
import net.minecraft.client.gui.inventory.GuiContainer;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ GuiContainer.class })
public class MixinGuiContainer
{
    @Shadow
    public Container field_147002_h;
    
    @Inject(method = { "drawSlot" }, at = { @At("TAIL") })
    private void drawSlot(final Slot slotIn, final CallbackInfo ci) {
        GuiContainerHook.drawSlot(this.field_147002_h, slotIn);
    }
}
