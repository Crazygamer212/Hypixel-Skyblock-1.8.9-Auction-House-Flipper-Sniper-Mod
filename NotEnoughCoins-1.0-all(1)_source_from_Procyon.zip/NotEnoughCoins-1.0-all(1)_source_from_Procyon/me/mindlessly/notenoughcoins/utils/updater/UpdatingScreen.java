// 
// Decompiled by Procyon v0.5.36
// 

package me.mindlessly.notenoughcoins.utils.updater;

import net.minecraft.util.MathHelper;
import net.minecraft.util.EnumChatFormatting;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.net.URLDecoder;
import me.mindlessly.notenoughcoins.Reference;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.File;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

public class UpdatingScreen extends GuiScreen
{
    private static final int DOT_TIME = 200;
    private static final String[] DOTS;
    private boolean failed;
    private boolean complete;
    private GuiButton backButton;
    private float progress;
    
    public UpdatingScreen(final boolean restartNow) {
        this.failed = false;
        this.complete = false;
        this.progress = 0.0f;
        this.doUpdate(restartNow);
    }
    
    public void func_73866_w_() {
        this.field_146292_n.add(this.backButton = new GuiButton(0, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 132, 200, 20, ""));
        this.updateText();
    }
    
    private void updateText() {
        this.backButton.field_146126_j = ((this.failed || this.complete) ? "OK" : "Cancel");
    }
    
    private void doUpdate(final boolean restartNow) {
        try {
            final File directory = new File(new File(Minecraft.func_71410_x().field_71412_D, "config"), "nec");
            final String url = GitHub.getUpdateDownloadUrl();
            final String jarName = GitHub.getJarNameFromUrl(url);
            final String url2;
            final File directory2;
            final String jarName2;
            new Thread(() -> {
                this.downloadUpdate(url2, directory2);
                if (!this.failed) {
                    GitHub.scheduleCopyUpdateAtShutdown(jarName2);
                    if (restartNow) {
                        Minecraft.func_71410_x().func_71400_g();
                    }
                    this.complete = true;
                    this.updateText();
                }
            }, "NEC Update Downloader Thread").start();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    private void downloadUpdate(final String url, final File directory) {
        try {
            final HttpURLConnection st = (HttpURLConnection)new URL(url).openConnection();
            st.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2");
            st.connect();
            if (st.getResponseCode() != 200) {
                this.failed = true;
                this.updateText();
                Reference.logger.error(url + " returned status code " + st.getResponseCode());
                return;
            }
            if (!directory.exists() && !directory.mkdirs()) {
                this.failed = true;
                this.updateText();
                Reference.logger.error("Couldn't create update file directory");
                return;
            }
            final String[] urlParts = url.split("/");
            final float fileLength = (float)st.getContentLength();
            final File fileSaved = new File(directory, URLDecoder.decode(urlParts[urlParts.length - 1], "UTF-8"));
            final InputStream fis = st.getInputStream();
            try (final OutputStream fos = new FileOutputStream(fileSaved)) {
                final byte[] data = new byte[1024];
                long total = 0L;
                int count;
                while ((count = fis.read(data)) != -1) {
                    if (Minecraft.func_71410_x().field_71462_r != this) {
                        fos.close();
                        fis.close();
                        this.failed = true;
                        return;
                    }
                    total += count;
                    this.progress = total / fileLength;
                    fos.write(data, 0, count);
                }
            }
            fis.close();
            if (Minecraft.func_71410_x().field_71462_r != this) {
                this.failed = true;
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
            this.failed = true;
            this.updateText();
        }
    }
    
    public void func_146284_a(final GuiButton button) {
        if (button.field_146127_k == 0) {
            Minecraft.func_71410_x().func_147108_a((GuiScreen)null);
        }
    }
    
    public void func_73863_a(final int mouseX, final int mouseY, final float partialTicks) {
        this.func_146276_q_();
        if (this.failed) {
            this.func_73732_a(Minecraft.func_71410_x().field_71466_p, EnumChatFormatting.RED + "Update download failed", this.field_146294_l / 2, this.field_146295_m / 2, -1);
        }
        else if (this.complete) {
            this.func_73732_a(Minecraft.func_71410_x().field_71466_p, EnumChatFormatting.GREEN + "Update download complete", this.field_146294_l / 2, this.field_146295_m / 2, 16777215);
        }
        else {
            final int left = Math.max(this.field_146294_l / 2 - 100, 10);
            final int right = Math.min(this.field_146294_l / 2 + 100, this.field_146294_l - 10);
            final int top = this.field_146295_m / 2 - 2 - MathHelper.func_76123_f(Minecraft.func_71410_x().field_71466_p.field_78288_b / 2.0f);
            final int bottom = this.field_146295_m / 2 + 2 + MathHelper.func_76141_d(Minecraft.func_71410_x().field_71466_p.field_78288_b / 2.0f);
            func_73734_a(left - 1, top - 1, right + 1, bottom + 1, -4144960);
            final int progressPoint = MathHelper.func_76125_a(MathHelper.func_76141_d(this.progress * (right - left) + left), left, right);
            func_73734_a(left, top, progressPoint, bottom, -3457739);
            func_73734_a(progressPoint, top, right, bottom, -1);
            final String label = String.format("%d%%", MathHelper.func_76125_a(MathHelper.func_76141_d(this.progress * 100.0f), 0, 100));
            Minecraft.func_71410_x().field_71466_p.func_78276_b(label, (this.field_146294_l - Minecraft.func_71410_x().field_71466_p.func_78256_a(label)) / 2, top + 3, -16777216);
            final int x = (this.field_146294_l - Minecraft.func_71410_x().field_71466_p.func_78256_a(String.format("Downloading %s", UpdatingScreen.DOTS[UpdatingScreen.DOTS.length - 1]))) / 2;
            final String title = String.format("Downloading %s", UpdatingScreen.DOTS[(int)(System.currentTimeMillis() % (200 * UpdatingScreen.DOTS.length)) / 200]);
            this.func_73731_b(Minecraft.func_71410_x().field_71466_p, title, x, top - Minecraft.func_71410_x().field_71466_p.field_78288_b - 2, -1);
        }
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }
    
    static {
        DOTS = new String[] { ".", "..", "...", "...", "..." };
    }
}
