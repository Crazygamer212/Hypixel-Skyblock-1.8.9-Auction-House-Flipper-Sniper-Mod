// 
// Decompiled by Procyon v0.5.36
// 

package me.mindlessly.notenoughcoins;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Reference
{
    public static final String MOD_ID = "nec";
    public static final String NAME = "NotEnoughCoins";
    public static final String VERSION = "v1.0";
    public static final Logger logger;
    
    static {
        logger = LogManager.getLogger("NotEnoughCoins");
    }
}
