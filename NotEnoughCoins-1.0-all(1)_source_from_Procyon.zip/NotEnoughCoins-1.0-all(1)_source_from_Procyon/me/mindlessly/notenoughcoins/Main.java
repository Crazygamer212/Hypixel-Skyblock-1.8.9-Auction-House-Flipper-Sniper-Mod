// 
// Decompiled by Procyon v0.5.36
// 

package me.mindlessly.notenoughcoins;

import java.util.LinkedList;
import java.util.HashMap;
import me.mindlessly.notenoughcoins.commands.subcommands.Token;
import me.mindlessly.notenoughcoins.commands.subcommands.Help;
import me.mindlessly.notenoughcoins.commands.subcommands.Toggle;
import me.mindlessly.notenoughcoins.commands.subcommands.Subcommand;
import me.mindlessly.notenoughcoins.websocket.Client;
import java.io.IOException;
import me.mindlessly.notenoughcoins.utils.Utils;
import me.mindlessly.notenoughcoins.utils.ApiHandler;
import me.mindlessly.notenoughcoins.events.OnGuiOpen;
import me.mindlessly.notenoughcoins.events.OnChatReceived;
import me.mindlessly.notenoughcoins.events.OnTooltip;
import me.mindlessly.notenoughcoins.events.OnTick;
import me.mindlessly.notenoughcoins.events.OnWorldJoin;
import net.minecraftforge.common.MinecraftForge;
import me.mindlessly.notenoughcoins.utils.updater.GitHub;
import net.minecraft.command.ICommand;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.fml.common.ProgressManager;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import java.io.File;
import java.util.List;
import java.util.Date;
import me.mindlessly.notenoughcoins.objects.AverageItem;
import java.util.Map;
import me.mindlessly.notenoughcoins.commands.NECCommand;
import net.minecraftforge.fml.common.Mod;

@Mod(modid = "nec", name = "NotEnoughCoins", version = "v1.0")
public class Main
{
    public static Config config;
    public static Authenticator authenticator;
    public static boolean checkedForUpdate;
    public static NECCommand commandManager;
    public static Map<String, AverageItem> averageItemMap;
    public static Map<String, Date> processedItem;
    public static Map<String, Integer> lbinItem;
    public static Map<String, Integer> bazaarItem;
    public static Map<String, Integer> npcItem;
    public static List<String> chatFilters;
    public static double balance;
    public static boolean justPlayedASound;
    public static File jarFile;
    
    @Mod.EventHandler
    public void preInit(final FMLPreInitializationEvent event) {
        Main.jarFile = event.getSourceFile();
    }
    
    @Mod.EventHandler
    public void init(final FMLInitializationEvent event) {
        final ProgressManager.ProgressBar progressBar = ProgressManager.push("Not Enough Coins", 4);
        Main.authenticator = new Authenticator(progressBar);
        try {
            Main.authenticator.authenticate(true);
        }
        catch (Exception e) {
            while (progressBar.getStep() < progressBar.getSteps() - 1) {
                progressBar.step("loading-failed-" + progressBar.getStep());
            }
            e.printStackTrace();
            Reference.logger.error("NotEnoughCoins have been disabled due to an error while authenticating. Please check the logs for more information.");
            return;
        }
        progressBar.step("Registering events, commands, hooks & tasks");
        Main.config.preload();
        ClientCommandHandler.instance.func_71560_a((ICommand)Main.commandManager);
        GitHub.downloadDeleteTask();
        MinecraftForge.EVENT_BUS.register((Object)new OnWorldJoin());
        MinecraftForge.EVENT_BUS.register((Object)new OnTick());
        MinecraftForge.EVENT_BUS.register((Object)new OnTooltip());
        MinecraftForge.EVENT_BUS.register((Object)new OnChatReceived());
        MinecraftForge.EVENT_BUS.register((Object)new OnGuiOpen());
        Tasks.updateBalance.start();
        Tasks.updateBazaarItem.start();
        Tasks.updateFilters.start();
        Utils.runInAThread(ApiHandler::updateNPC);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            Reference.logger.info("Logging out...");
            try {
                Main.authenticator.logout();
            }
            catch (IOException e2) {
                e2.printStackTrace();
            }
            return;
        }));
        progressBar.step("Establishing WebSocket Connection");
        Client.connectWithToken();
        ProgressManager.pop(progressBar);
    }
    
    static {
        Main.config = new Config();
        Main.checkedForUpdate = false;
        Main.commandManager = new NECCommand(new Subcommand[] { new Toggle(), new Help(), new Token() });
        Main.averageItemMap = new HashMap<String, AverageItem>();
        Main.processedItem = new HashMap<String, Date>();
        Main.lbinItem = new HashMap<String, Integer>();
        Main.bazaarItem = new HashMap<String, Integer>();
        Main.npcItem = new HashMap<String, Integer>();
        Main.chatFilters = new LinkedList<String>();
        Main.balance = 0.0;
        Main.justPlayedASound = false;
    }
}
