// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket;

import java.nio.ByteBuffer;
import java.io.IOException;
import java.nio.channels.ByteChannel;

public interface WrappedByteChannel extends ByteChannel
{
    boolean isNeedWrite();
    
    void writeMore() throws IOException;
    
    boolean isNeedRead();
    
    int readMore(final ByteBuffer p0) throws IOException;
    
    boolean isBlocking();
}
