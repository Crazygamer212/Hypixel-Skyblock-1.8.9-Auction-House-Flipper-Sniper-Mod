// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket;

import org.java_websocket.framing.PongFrame;
import org.java_websocket.framing.Framedata;
import org.java_websocket.handshake.ServerHandshake;
import org.java_websocket.exceptions.InvalidDataException;
import org.java_websocket.handshake.HandshakeImpl1Server;
import org.java_websocket.handshake.ServerHandshakeBuilder;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.drafts.Draft;
import org.java_websocket.framing.PingFrame;

public abstract class WebSocketAdapter implements WebSocketListener
{
    private PingFrame pingFrame;
    
    @Override
    public ServerHandshakeBuilder onWebsocketHandshakeReceivedAsServer(final WebSocket conn, final Draft draft, final ClientHandshake request) throws InvalidDataException {
        return new HandshakeImpl1Server();
    }
    
    @Override
    public void onWebsocketHandshakeReceivedAsClient(final WebSocket conn, final ClientHandshake request, final ServerHandshake response) throws InvalidDataException {
    }
    
    @Override
    public void onWebsocketHandshakeSentAsClient(final WebSocket conn, final ClientHandshake request) throws InvalidDataException {
    }
    
    @Override
    public void onWebsocketPing(final WebSocket conn, final Framedata f) {
        conn.sendFrame(new PongFrame((PingFrame)f));
    }
    
    @Override
    public void onWebsocketPong(final WebSocket conn, final Framedata f) {
    }
    
    @Override
    public PingFrame onPreparePing(final WebSocket conn) {
        if (this.pingFrame == null) {
            this.pingFrame = new PingFrame();
        }
        return this.pingFrame;
    }
}
