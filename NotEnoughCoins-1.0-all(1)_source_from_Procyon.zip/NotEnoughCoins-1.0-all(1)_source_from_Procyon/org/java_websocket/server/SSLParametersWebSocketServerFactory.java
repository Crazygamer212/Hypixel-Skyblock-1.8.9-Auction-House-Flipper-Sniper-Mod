// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket.server;

import java.io.IOException;
import javax.net.ssl.SSLEngine;
import org.java_websocket.SSLSocketChannel2;
import java.nio.channels.ByteChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;

public class SSLParametersWebSocketServerFactory extends DefaultSSLWebSocketServerFactory
{
    private final SSLParameters sslParameters;
    
    public SSLParametersWebSocketServerFactory(final SSLContext sslContext, final SSLParameters sslParameters) {
        this(sslContext, Executors.newSingleThreadScheduledExecutor(), sslParameters);
    }
    
    public SSLParametersWebSocketServerFactory(final SSLContext sslContext, final ExecutorService executerService, final SSLParameters sslParameters) {
        super(sslContext, executerService);
        if (sslParameters == null) {
            throw new IllegalArgumentException();
        }
        this.sslParameters = sslParameters;
    }
    
    @Override
    public ByteChannel wrapChannel(final SocketChannel channel, final SelectionKey key) throws IOException {
        final SSLEngine e = this.sslcontext.createSSLEngine();
        e.setUseClientMode(false);
        e.setSSLParameters(this.sslParameters);
        return new SSLSocketChannel2(channel, e, this.exec, key);
    }
}
