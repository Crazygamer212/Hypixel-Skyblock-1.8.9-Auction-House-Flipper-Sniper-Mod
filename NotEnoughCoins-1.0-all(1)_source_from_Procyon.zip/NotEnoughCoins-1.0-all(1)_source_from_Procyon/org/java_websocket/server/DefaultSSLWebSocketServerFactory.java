// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket.server;

import org.java_websocket.WebSocket;
import org.java_websocket.WebSocketListener;
import org.java_websocket.WebSocketImpl;
import org.java_websocket.drafts.Draft;
import org.java_websocket.WebSocketAdapter;
import java.io.IOException;
import java.util.List;
import javax.net.ssl.SSLEngine;
import org.java_websocket.SSLSocketChannel2;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Arrays;
import java.nio.channels.ByteChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import javax.net.ssl.SSLContext;
import org.java_websocket.WebSocketServerFactory;

public class DefaultSSLWebSocketServerFactory implements WebSocketServerFactory
{
    protected SSLContext sslcontext;
    protected ExecutorService exec;
    
    public DefaultSSLWebSocketServerFactory(final SSLContext sslContext) {
        this(sslContext, Executors.newSingleThreadScheduledExecutor());
    }
    
    public DefaultSSLWebSocketServerFactory(final SSLContext sslContext, final ExecutorService exec) {
        if (sslContext == null || exec == null) {
            throw new IllegalArgumentException();
        }
        this.sslcontext = sslContext;
        this.exec = exec;
    }
    
    @Override
    public ByteChannel wrapChannel(final SocketChannel channel, final SelectionKey key) throws IOException {
        final SSLEngine e = this.sslcontext.createSSLEngine();
        final List<String> ciphers = new ArrayList<String>(Arrays.asList(e.getEnabledCipherSuites()));
        ciphers.remove("TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256");
        e.setEnabledCipherSuites(ciphers.toArray(new String[ciphers.size()]));
        e.setUseClientMode(false);
        return new SSLSocketChannel2(channel, e, this.exec, key);
    }
    
    @Override
    public WebSocketImpl createWebSocket(final WebSocketAdapter a, final Draft d) {
        return new WebSocketImpl(a, d);
    }
    
    @Override
    public WebSocketImpl createWebSocket(final WebSocketAdapter a, final List<Draft> d) {
        return new WebSocketImpl(a, d);
    }
    
    @Override
    public void close() {
        this.exec.shutdown();
    }
}
