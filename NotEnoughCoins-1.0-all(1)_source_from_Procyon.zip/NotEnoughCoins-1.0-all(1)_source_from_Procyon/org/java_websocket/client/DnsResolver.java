// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket.client;

import java.net.UnknownHostException;
import java.net.InetAddress;
import java.net.URI;

public interface DnsResolver
{
    InetAddress resolve(final URI p0) throws UnknownHostException;
}
