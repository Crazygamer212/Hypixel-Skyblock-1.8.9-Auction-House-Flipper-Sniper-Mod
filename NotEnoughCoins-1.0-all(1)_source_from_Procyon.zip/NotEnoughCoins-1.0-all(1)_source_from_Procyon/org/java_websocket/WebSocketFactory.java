// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket;

import java.util.List;
import org.java_websocket.drafts.Draft;

public interface WebSocketFactory
{
    WebSocket createWebSocket(final WebSocketAdapter p0, final Draft p1);
    
    WebSocket createWebSocket(final WebSocketAdapter p0, final List<Draft> p1);
}
