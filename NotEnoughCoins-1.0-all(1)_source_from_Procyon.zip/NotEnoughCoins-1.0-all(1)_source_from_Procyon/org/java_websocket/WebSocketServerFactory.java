// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket;

import java.io.IOException;
import java.nio.channels.ByteChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import java.util.List;
import org.java_websocket.drafts.Draft;

public interface WebSocketServerFactory extends WebSocketFactory
{
    WebSocketImpl createWebSocket(final WebSocketAdapter p0, final Draft p1);
    
    WebSocketImpl createWebSocket(final WebSocketAdapter p0, final List<Draft> p1);
    
    ByteChannel wrapChannel(final SocketChannel p0, final SelectionKey p1) throws IOException;
    
    void close();
}
