// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket.handshake;

public interface HandshakeBuilder extends Handshakedata
{
    void setContent(final byte[] p0);
    
    void put(final String p0, final String p1);
}
