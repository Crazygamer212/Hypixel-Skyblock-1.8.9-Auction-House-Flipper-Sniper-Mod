// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket.framing;

import org.java_websocket.exceptions.InvalidDataException;
import org.java_websocket.enums.Opcode;

public abstract class DataFrame extends FramedataImpl1
{
    public DataFrame(final Opcode opcode) {
        super(opcode);
    }
    
    @Override
    public void isValid() throws InvalidDataException {
    }
}
