// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket.framing;

import org.java_websocket.exceptions.InvalidDataException;
import org.java_websocket.util.Charsetfunctions;
import org.java_websocket.enums.Opcode;

public class TextFrame extends DataFrame
{
    public TextFrame() {
        super(Opcode.TEXT);
    }
    
    @Override
    public void isValid() throws InvalidDataException {
        super.isValid();
        if (!Charsetfunctions.isValidUTF8(this.getPayloadData())) {
            throw new InvalidDataException(1007, "Received text is no valid utf8 string!");
        }
    }
}
