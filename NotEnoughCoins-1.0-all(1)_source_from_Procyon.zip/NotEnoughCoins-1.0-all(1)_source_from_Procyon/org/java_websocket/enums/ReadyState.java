// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket.enums;

public enum ReadyState
{
    NOT_YET_CONNECTED, 
    OPEN, 
    CLOSING, 
    CLOSED;
}
