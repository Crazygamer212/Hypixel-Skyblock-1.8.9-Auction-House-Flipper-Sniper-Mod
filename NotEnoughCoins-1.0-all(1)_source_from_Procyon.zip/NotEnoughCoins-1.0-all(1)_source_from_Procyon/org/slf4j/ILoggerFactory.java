// 
// Decompiled by Procyon v0.5.36
// 

package org.slf4j;

public interface ILoggerFactory
{
    Logger getLogger(final String p0);
}
