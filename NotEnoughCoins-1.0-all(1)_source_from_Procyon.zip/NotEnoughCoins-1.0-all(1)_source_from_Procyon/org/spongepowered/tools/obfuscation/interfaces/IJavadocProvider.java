// 
// Decompiled by Procyon v0.5.36
// 

package org.spongepowered.tools.obfuscation.interfaces;

import javax.lang.model.element.Element;

public interface IJavadocProvider
{
    String getJavadoc(final Element p0);
}
